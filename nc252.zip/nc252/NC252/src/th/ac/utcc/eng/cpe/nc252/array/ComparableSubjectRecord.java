package th.ac.utcc.eng.cpe.nc252.array;

public class ComparableSubjectRecord {

}
