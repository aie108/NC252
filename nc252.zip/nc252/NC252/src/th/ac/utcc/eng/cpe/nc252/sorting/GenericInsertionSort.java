package th.ac.utcc.eng.cpe.nc252.sorting;

import java.lang.reflect.Array;

public class GenericInsertionSort<T extends Comparable<T>> {
	private T [] element;
	private int eSize;
	
	@SuppressWarnings("unchecked")
	public GenericInsertionSort(Class<T> objectType,int size) {
		if(size > 0)	
			this.element = (T[])(Array.newInstance(objectType, size));
		else
			// default element.length == 10
			this.element = (T[])(Array.newInstance(objectType, 10));
		
		eSize = 0;
	}
	
	public void insert(T e) {
		this.element[eSize] = e;
		eSize++;
	}
	
	public void show() {
		for(int i=0; i < eSize; i++) {
			System.out.print(this.element[i] + " ");
		}
		
		System.out.println("");
	}
	
	public void sort() {
		int out, in;
		T   temp;
		
		for(out = 1; out < eSize; out++) {
			temp = this.element[out];
			for(in = out; in > 0 && (this.element[in-1]).compareTo(temp) == -1; in--) {
				this.element[in] = this.element[in - 1];
			}
			this.element[in] = temp;
		}
	}
	
	public static void main(String[] args) {
		// 
		int max = 20;
		GenericInsertionSort<Integer> insertionSort = new GenericInsertionSort<Integer>(Integer.class, max);
		
		insertionSort.insert(87);
		insertionSort.insert(43);
		insertionSort.insert(95);
		insertionSort.insert(32);
		insertionSort.insert(91);
		insertionSort.insert(78);
		insertionSort.insert(26);
		insertionSort.insert(12);

		// show original order
		System.out.print("Original Order: ");
		insertionSort.show();
		
		// sort and then show the result
		insertionSort.sort();
		System.out.print("  Sorted Order: ");
		insertionSort.show();
	}
}
