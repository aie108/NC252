package th.ac.utcc.eng.cpe.nc252.array;

public class SubjectRecord implements Comparable<Object> {
	private String code;
	private String name;
	private float unit;
	private String grade;
	
	public SubjectRecord() {
		
	}
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getUnit() {
		return unit;
	}
	public void setUnit(float unit) {
		this.unit = unit;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	
	public String toString() {
		return code + " " + name + " " + unit + " " + grade;
	}

	@Override
	public int compareTo(Object o) {
		return this.code.compareToIgnoreCase(((SubjectRecord)o).getCode()); 
	}
}
