package th.ac.utcc.eng.cpe.nc252.sorting;

public class BubbleSort {
	private int [] element;
	private int eSize;
	
	public BubbleSort(int size) {
		if(size > 0)
			this.element = new int[size];
		else
			// default element.length == 10
			this.element = new int[10];
		
		eSize = 0;
	}
	
	public void insert(int e) {
		this.element[eSize] = e;
		eSize++;
	}
	
	public void show() {
		for(int i=0; i < eSize; i++) {
			System.out.print(this.element[i] + " ");
		}
		
		System.out.println("");
	}
	
	public void sort() {
		int out, in;
		int count = 0;
		
		for(out = eSize - 1; out > 0; out--) {
			for(in = 0; in < out; in++) {
				if(this.element[in] > this.element[in + 1]) {
					this.swap(in, in+1);
					count++;
				}
			}
		}
		
		System.out.println("# of swap calls:" + count);
	}
	
	private void swap(int left, int right) {
		int temp = this.element[left];
		this.element[left] = this.element[right];
		this.element[right] = temp;
	}
	
	public static void main(String[] args) {
		// 
		int max = 20;
		BubbleSort bubble = new BubbleSort(max);
		
		bubble.insert(8);
		bubble.insert(6);
		bubble.insert(4);
		bubble.insert(3);
		bubble.insert(9);
		bubble.insert(1);

		// show original order
		System.out.print("Original Order: ");
		bubble.show();
		
		// sort and then show the result
		bubble.sort();
				
		System.out.print("Sorted Order: ");
		bubble.show();
	}
}
