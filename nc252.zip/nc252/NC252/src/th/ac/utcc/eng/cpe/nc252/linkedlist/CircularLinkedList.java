package th.ac.utcc.eng.cpe.nc252.linkedlist;

public class CircularLinkedList {
	private MyNumber first;
	private MyNumber current, previous;
	private MyNumber last;
	private int size;
	
	public CircularLinkedList() {
		first = null;
		current = null;
		previous = null;
		last = null;
		size = 0;
	}
	
	public int getSize() {
		return size;
	}
	
	public boolean isNull() {
		return first == null;
	}
	
	public void insertLast(MyNumber newData) {
		if(first == null) {
			// update first
			first = newData;
			newData.next = first;

			// update last
			last = first;
		} else {
			last.next = newData;
			last = newData;
		}
		
		size++;
	}
	
	public MyNumber delete() {
		MyNumber temp = current;
		if(current != null) {
			
			// update 'previous'
			previous.next = current.next;
			
			// if delete the first element, must update 'first'
			if(current.getNumber() == first.getNumber())
				first = current.next;
			
			// update 'current'
			current = current.next;
			size--;
		}
		
		return temp;
	}
	
	public void move(int n) {
		if(current == null) {
			current = first;	
		} 

		for(int i=0; i < n-1; i++) {
			previous = current;
			if(current.next != null)
				current = current.next;
			else
				current = first;
			
		}
	}
	
	public String toString() {
		MyNumber m = first;
		String s = "{";
		int i=0; 
		while(i < size) {
			s += m;
			m = m.next;
			i++;
			if(i != size)
				s += ", ";
			else
				s += "}";
		}
		
		return s;
	}
	
	public void display() {
		MyNumber cur = first;
		for(int i=0; i < size; i++) {
			System.out.print(cur + " ");
			cur = cur.next;
		}
	}
	
}
