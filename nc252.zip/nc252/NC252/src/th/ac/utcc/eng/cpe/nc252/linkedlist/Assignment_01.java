package th.ac.utcc.eng.cpe.nc252.linkedlist;

public class Assignment_01 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		CircularLinkedList myList = new CircularLinkedList();
		
		for(int i=0; i < 7; i++) {
			MyNumber n = new MyNumber(i);
			myList.insertLast(n);
		}
		System.out.println("Original List:");
		myList.display();
		
		for(int i=1; myList.getSize() != 1; i++) {
			System.out.print("\nStep: " + i + ": ");
			myList.move(4);
			myList.delete();
			System.out.println(myList);
			
		}
	}

}
