package th.ac.utcc.eng.cpe.nc252.linkedlist;

public class MyNumber {
	private int number;
	MyNumber next;

	public MyNumber() {
		number = -1;
	}
	public MyNumber(int n) {
		number = n;
	}
	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}
	
	public String toString() {
		return "" + this.number;
	}
}
