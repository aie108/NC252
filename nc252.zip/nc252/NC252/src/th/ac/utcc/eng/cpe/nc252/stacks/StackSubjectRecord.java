/**
 * @author 59xxxxxx Suparerk
 */
package th.ac.utcc.eng.cpe.nc252.stacks;

import th.ac.utcc.eng.cpe.nc252.array.SubjectRecord;

public class StackSubjectRecord {
	private int max;
	private SubjectRecord [] aSubjectRecord;
	private int top;
	
	public StackSubjectRecord(int max) {
		this.max = max;
		aSubjectRecord = new SubjectRecord[max];
		top = -1;
	}
	
	public void push(SubjectRecord subjectRecord) {
		aSubjectRecord[++top] = subjectRecord;
	}
	
	public SubjectRecord pop() {
		return aSubjectRecord[top--];
	}
	
	public boolean isEmpty() {
		return (top == -1);
	}
	
	public boolean isFull() {
		return (top == max - 1);
	}
	public static void main(String[] args) {
		SubjectRecord s1 = new SubjectRecord();
		s1.setCode("NC252");
		s1.setName("Data Structure");
		s1.setUnit(3);
		s1.setGrade("A");
		
		SubjectRecord s2 = new SubjectRecord();
		s2.setCode("NG151");
		s2.setName("Programming");
		s2.setUnit(3);
		s2.setGrade("B");
		
		SubjectRecord s3 = new SubjectRecord();
		s3.setCode("NG153");
		s3.setName("Advanced Programming");
		s3.setUnit(3);
		s3.setGrade("C");
		
		StackSubjectRecord stack = new StackSubjectRecord(10);
		stack.push(s1);
		stack.push(s2);
		stack.push(s3);
		
		SubjectRecord s4 = stack.pop();
		System.out.println(s4);
		
		SubjectRecord s5 = stack.pop();
		System.out.println(s5);
		
		SubjectRecord s6 = stack.pop();
		System.out.println(s6);
	}

}
